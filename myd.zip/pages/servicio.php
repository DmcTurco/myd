<?php
/**
 * Pagina de detalle de un servicio.
 *
 * No hay maquetacion fija: se dibuja lo que diga data/servicios.php, que a su
 * vez sale del contenido original de WordPress. Asi cada servicio conserva su
 * propia estructura (cabecera con foto, texto, dos columnas, tarjetas, logos).
 */
require_once __DIR__ . '/../data/servicios.php';
require_once __DIR__ . '/../data/menu.php';

$slug = $_GET['s'] ?? '';
$pag  = $servicios_paginas[$slug] ?? null;

if (!$pag) {
    echo '<div class="container" style="padding:80px 0;text-align:center;">'
       . '<h2>Servicio no encontrado</h2>'
       . '<a href="' . page_url('servicios') . '" class="btn btn--primary">Ver todos los servicios</a></div>';
    return;
}

// En el original la barra de migas solo sale en las 10 fichas de seguro, y
// ademas solo con dos niveles: Home > titulo. Las otras cuatro paginas de
// servicio no la llevan.
$lleva_migas = !empty($pag['migas']);

// Fracciones de ancho -> sufijo de clase CSS
$anchos = [
    '1/1' => '1-1', '1/2' => '1-2', '1/3' => '1-3', '2/3' => '2-3',
    '1/4' => '1-4', '3/4' => '3-4', '1/6' => '1-6', '5/6' => '5-6',
];

// 'right top' y similares -> valores validos de background-position
function servicio_bgpos(string $p): string
{
    $p = trim($p) ?: 'right top';
    $mapa = ['right top' => '100% 0%', 'center center' => '50% 50%', 'left top' => '0% 0%', 'center top' => '50% 0%'];
    return $mapa[$p] ?? $p;
}
?>

<?php if ($lleva_migas): ?>
<!-- ===== BARRA DE MIGAS ===== -->
<section class="subheader subheader--bar">
    <div class="container">
        <nav class="breadcrumb-bar" aria-label="breadcrumb">
            <ol class="breadcrumb-list">
                <li><a href="<?= page_url('home') ?>">Home</a></li>
                <li><?= htmlspecialchars($pag['titulo']) ?></li>
            </ol>
        </nav>
    </div>
</section>
<?php endif; ?>

<?php foreach ($pag['filas'] as $fila): ?>
<?php
    $clases = ['vcrow'];
    $clases[] = (($fila['ancho'] ?? 'fullwidth') === 'default') ? 'vcrow--caja' : 'vcrow--full';
    if (!empty($fila['grid']))    { $clases[] = 'vcrow--grid'; }

    // Fila que solo lleva el separador: se marca para poder acotarla a 1180px
    $solo_sep = true;
    foreach ($fila['cols'] as $c) {
        foreach ($c['items'] ?? [] as $i) {
            if ($i['t'] !== 'separador') { $solo_sep = false; break 2; }
        }
    }
    if ($solo_sep) { $clases[] = 'vcrow--sep'; }
    if (!empty($fila['bordes']))  { $clases[] = 'vcrow--borde-' . $fila['bordes']; }
    if (!empty($fila['bg'])) {
        $clases[] = 'vcrow--foto';
        // 'parallax' recorta la imagen mas arriba; 'classic' la deja a ras
        $clases[] = (($fila['efecto'] ?? '') === 'parallax') ? 'vcrow--parallax' : 'vcrow--clasica';
    }

    $estilo = '';
    if (isset($fila['pt'])) { $estilo .= 'padding-top:' . (int) $fila['pt'] . 'px;'; }
    if (isset($fila['pb'])) { $estilo .= 'padding-bottom:' . (int) $fila['pb'] . 'px;'; }
?>
<section class="<?= implode(' ', $clases) ?>"<?= $estilo ? ' style="' . $estilo . '"' : '' ?>>

    <?php if (!empty($fila['bg'])): ?>
    <!-- Capa de fondo: reproduce el recorte del efecto parallax del sitio original -->
    <span class="vcrow__foto" style="background-image:url('<?= asset('images/servicios/' . $fila['bg']) ?>');background-position:<?= servicio_bgpos($fila['bgpos'] ?? '') ?>;"></span>
    <?php endif; ?>

    <div class="vcrow__inner">
        <?php foreach ($fila['cols'] as $col):
            $ecol = '';
            if (isset($col['pt'])) { $ecol .= 'padding-top:' . (int) $col['pt'] . 'px;'; }
            if (isset($col['pb'])) { $ecol .= 'padding-bottom:' . (int) $col['pb'] . 'px;'; }
        ?>
        <div class="vccol vccol--<?= $anchos[$col['w']] ?? '1-1' ?>"<?= $ecol ? ' style="' . $ecol . '"' : '' ?>>
            <?php foreach ($col['items'] ?? [] as $it): ?>

                <?php if ($it['t'] === 'heading' && trim($it['txt']) === '' && empty($it['punchline'])): ?>
                <?php /* Titulo vacio en el original: solo deja el hueco que ocupaba */ ?>
                <div class="rt-head rt-head--vacia"></div>

                <?php elseif ($it['t'] === 'heading'):
                    $tag = in_array($it['size'], ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'], true) ? $it['size'] : 'h2'; ?>
                <div class="rt-head rt-head--<?= htmlspecialchars($it['estilo']) ?>">
                    <?php if (!empty($it['punchline'])): ?>
                    <span class="rt-punch"><?= htmlspecialchars($it['punchline']) ?></span>
                    <?php endif; ?>
                    <<?= $tag ?> class="rt-title"><?= $it['txt'] ?></<?= $tag ?>>
                </div>

                <?php elseif ($it['t'] === 'texto'): ?>
                <div class="rt-texto">
                    <?php $h = trim($it['html']);
                          echo (strpos($h, '<') === 0) ? $h : '<p>' . $h . '</p>'; ?>
                </div>

                <?php elseif ($it['t'] === 'imagen'): ?>
                <figure class="rt-img">
                    <img src="<?= asset('images/servicios/' . $it['src']) ?>" alt="<?= htmlspecialchars($pag['titulo']) ?>">
                </figure>

                <?php elseif ($it['t'] === 'separador'): ?>
                <div class="rt-sep"></div>
                <?php endif; ?>

            <?php endforeach; ?>
        </div>
        <?php endforeach; ?>
    </div>
</section>
<?php endforeach; ?>
